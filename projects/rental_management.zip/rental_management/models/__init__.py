# -*- coding: utf-8 -*-

from . import rental
from . import product
from . import sale
from . import hr_employee