# -*- coding: utf-8 -*-

from . import smart
from . import new
from . import new_sale
from . import sale_order
from . import res_partner
from . import res_settings
