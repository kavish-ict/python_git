# -*- coding: utf-8 -*-

# from . import w_wizard
from . import student_info_wizard