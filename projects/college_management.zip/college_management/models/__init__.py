# -*- coding: utf-8 -*-

from . import college_management

