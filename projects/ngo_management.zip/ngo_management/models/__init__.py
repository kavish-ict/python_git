
from . import res_partner
from . import orphan_organization
from . import orphan_request
