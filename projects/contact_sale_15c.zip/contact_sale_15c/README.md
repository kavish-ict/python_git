Odoo 13.0 Community

Installation 
============
* Install the Application => Apps -> Contact Sale (Technical Name: contact_sale)



Contact Sale
==================================
* Select the contact and it's Sale order, and you can check history log of the all activity done on that order record. 


Steps
=====
* Go to Sale -> Configuration -> Contact Sale after installing the module and select the contact and it's orders that you want.

15.0.1.0.0
===========
* New Project



