Advance Action
----------------
This  module is for advance actions like sending mail, create, write.
