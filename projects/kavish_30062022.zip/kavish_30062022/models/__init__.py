# -*- coding: utf-8 -*-

from . import sale_order
from . import product_product
from . import sale_order_line
from . import invoice_lines
from . import account_move

