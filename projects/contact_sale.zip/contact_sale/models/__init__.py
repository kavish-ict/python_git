# -*- coding: utf-8 -*-

from . import contact_sale
from . import res_partner

