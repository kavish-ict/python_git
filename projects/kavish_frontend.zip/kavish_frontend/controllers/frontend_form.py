# -*- coding: utf-8 -*-
from odoo import http, _
from odoo.http import request
from odoo.addons.portal.controllers import portal


class Website(http.Controller):
    """
    class for Website
    """

    @http.route(['/contact'], type='http', auth="user", website=True)
    def contact_creation(self, **kw):
        """
        function to open the form page and search records of
        res partner
        """
        contact_name = request.env['res.partner'].sudo().search([])
        return request.render("kavish_frontend.exam_frontend_form", {'record': contact_name})

    @http.route(['/contact/submit'], type='http', auth="user", website=True)
    def create_contactl(self, **kw):
        """
        function to create record in res partner
        """
        if kw:
            request.env['res.partner'].sudo().create(kw)
        return request.render(
            "kavish_frontend.contact_form_record", {})
