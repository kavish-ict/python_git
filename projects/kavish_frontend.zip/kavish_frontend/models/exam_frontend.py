from odoo import models, fields, api


class ExamFrontend(models.Model):
    """
    class for testing frontend
    """
    _name = 'exam.frontend'
    _description = "model for testing frontend"
